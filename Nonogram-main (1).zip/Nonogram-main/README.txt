add comments
add padding for user inputs